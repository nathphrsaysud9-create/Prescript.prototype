/*
 * Design reminder — Index Terminal:
 * Preserve the black terminal viewport, Index Cyan accents, monospace command copy,
 * deliberate ritual flow, and a safe user-controlled Complete/Skip interaction.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { Check, ChevronDown, CircleHelp, Copy, Database, Menu, Plus, Radio, RotateCcw, Settings2, SkipForward, Sparkles, Trash2, X, Volume2, VolumeX, Upload } from "lucide-react";
import { toast } from "sonner";

const STORAGE = {
  name: "prescript.name",
  words: "prescript.words",
  stats: "prescript.stats",
};

const starterWords = [
  "a quiet room",
  "the nearest blue object",
  "five deliberate steps",
  "an unfinished thought",
  "a page you have not read",
  "the sound outside your window",
  "a glass of water",
  "your own reflection",
];

const safeTemplates = [
  "Walk {count} steps, then pause and notice one detail you would usually miss.",
  "Write the word {word} in your notes. Do not explain it.",
  "Find {word}. Look at it for {seconds} seconds, then return to where you began.",
  "Say {word} quietly once. Let the silence remain for {seconds} seconds.",
  "Arrange three objects near you. The smallest one must face {direction}.",
  "Move {count} steps toward {direction}. Stop before entering another person's space.",
  "Observe {word}. Record one color, one shape, and one sound.",
  "For {seconds} seconds, do nothing except listen. Afterwards, drink water.",
];

const glyphs = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!?#%&+-=[]{}<>/\\|_:;";
const directions = ["north", "east", "south", "west"];

function tone(frequency: number, duration: number, type: OscillatorType = "sine", volume = 0.045) {
  const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return;
  const context = new AudioContextClass();
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  oscillator.type = type;
  oscillator.frequency.value = frequency;
  gain.gain.setValueAtTime(volume, context.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + duration);
  oscillator.connect(gain).connect(context.destination);
  oscillator.start();
  oscillator.stop(context.currentTime + duration);
  window.setTimeout(() => context.close(), Math.ceil(duration * 1000) + 100);
}

function signalBurst() {
  tone(880, .08, "square", .035);
  window.setTimeout(() => tone(1320, .1, "sawtooth", .025), 85);
}

function staticBurst() {
  tone(120, .12, "sawtooth", .018);
  window.setTimeout(() => tone(420, .07, "square", .014), 40);
}

function pick<T>(items: T[]) {
  return items[Math.floor(Math.random() * items.length)];
}

function makeCommand(words: string[]) {
  const template = pick(safeTemplates);
  return template
    .replace("{word}", pick(words))
    .replace("{word}", pick(words))
    .replace("{count}", String(Math.floor(Math.random() * 8) + 3))
    .replace("{seconds}", String(Math.floor(Math.random() * 25) + 10))
    .replace("{direction}", pick(directions));
}

function randomizeLine(line: string, revealCount: number) {
  return line.split("").map((character, index) => {
    if (character === " ") return " ";
    if (index < revealCount) return character;
    return Math.random() > 0.18 ? glyphs[Math.floor(Math.random() * glyphs.length)] : "█";
  }).join("");
}

export default function Home() {
  const [name, setName] = useState(() => localStorage.getItem(STORAGE.name) || "Proselyte");
  const [nameDraft, setNameDraft] = useState(name);
  const [words, setWords] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE.words) || "null") || starterWords; } catch { return starterWords; }
  });
  const [newWord, setNewWord] = useState("");
  const [command, setCommand] = useState(() => makeCommand(starterWords));
  const [display, setDisplay] = useState("");
  const [phase, setPhase] = useState<"idle" | "revealing" | "ready" | "complete">("idle");
  const [revealCount, setRevealCount] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [showLexicon, setShowLexicon] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(() => localStorage.getItem("prescript.sound") !== "off");
  const [customSoundName, setCustomSoundName] = useState("");
  const customSoundUrl = useRef<string | null>(null);
  const [stats, setStats] = useState(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE.stats) || "null") || { received: 0, complete: 0, skipped: 0 }; } catch { return { received: 0, complete: 0, skipped: 0 }; }
  });

  const lineCount = useMemo(() => command.split(" ").length, [command]);

  useEffect(() => { localStorage.setItem(STORAGE.words, JSON.stringify(words)); }, [words]);
  useEffect(() => { localStorage.setItem(STORAGE.stats, JSON.stringify(stats)); }, [stats]);

  useEffect(() => {
    if (phase === "idle") { setDisplay("AWAITING PRESCRIPT"); return; }
    if (phase === "complete") { setDisplay("PRESCRIPT COMPLETE"); return; }
    if (phase === "ready") { setDisplay(command); return; }
    const timer = window.setInterval(() => {
      setRevealCount((current) => {
        const next = Math.min(current + 2, command.length + 1);
        if (next >= command.length + 1) {
          window.clearInterval(timer);
          setPhase("ready");
          return command.length + 1;
        }
        return next;
      });
    }, 72);
    return () => window.clearInterval(timer);
  }, [phase, command]);

  useEffect(() => {
    if (phase === "revealing") setDisplay(randomizeLine(command, revealCount));
  }, [phase, revealCount, command]);

  function playCustomSound() {
    if (!customSoundUrl.current) return;
    const audio = new Audio(customSoundUrl.current);
    audio.volume = 0.32;
    void audio.play().catch(() => undefined);
  }

  function receive() {
    const next = makeCommand(words.length ? words : starterWords);
    if (soundEnabled) { playCustomSound(); signalBurst(); window.setTimeout(() => staticBurst(), 180); }
    setCommand(next);
    setRevealCount(0);
    setPhase("revealing");
    setStats((current: typeof stats) => ({ ...current, received: current.received + 1 }));
    toast("SIGNAL RECEIVED", { description: "The Prescript is being decoded." });
  }

  function finish(kind: "complete" | "skip") {
    if (soundEnabled) { playCustomSound(); kind === "complete" ? tone(1046, .16, "sine", .04) : staticBurst(); }
    setPhase(kind === "complete" ? "complete" : "idle");
    if (kind === "complete") setStats((current: typeof stats) => ({ ...current, complete: current.complete + 1 }));
    else setStats((current: typeof stats) => ({ ...current, skipped: current.skipped + 1 }));
    toast(kind === "complete" ? "PRESCRIPT ARCHIVED" : "PRESCRIPT DECLINED", { description: kind === "complete" ? "The record has been marked complete." : "No consequence. The signal is cleared." });
  }

  function saveName() {
    const clean = nameDraft.trim() || "Proselyte";
    setName(clean);
    localStorage.setItem(STORAGE.name, clean);
    toast("IDENTITY UPDATED", { description: `Receiving Prescripts as ${clean}.` });
  }

  function addWord(event: React.FormEvent) {
    event.preventDefault();
    const clean = newWord.trim();
    if (!clean) return;
    if (words.some((word) => word.toLowerCase() === clean.toLowerCase())) {
      toast("ENTRY ALREADY EXISTS");
      return;
    }
    setWords((current) => [...current, clean]);
    setNewWord("");
    toast("LEXICON UPDATED", { description: `Added “${clean}”.` });
  }

  function removeWord(word: string) {
    setWords((current) => current.filter((entry) => entry !== word));
  }

  function toggleSound() {
    setSoundEnabled((current) => {
      const next = !current;
      localStorage.setItem("prescript.sound", next ? "on" : "off");
      if (next) signalBurst();
      toast(next ? "AUDIO LINK ENABLED" : "AUDIO LINK MUTED");
      return next;
    });
  }

  function loadSound(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (customSoundUrl.current) URL.revokeObjectURL(customSoundUrl.current);
    customSoundUrl.current = URL.createObjectURL(file);
    setCustomSoundName(file.name);
    toast("LOCAL SOUND REGISTERED", { description: "The selected file will play with the next signal." });
  }

  const decoded = phase === "revealing" ? display : phase === "idle" ? "AWAITING PRESCRIPT" : phase === "complete" ? "PRESCRIPT COMPLETE" : command;

  return (
    <main className="prescript-shell">
      <header className="topbar">
        <div className="brand-lockup" aria-label="The Index Prescript">
          <img src="/manus-storage/index-terminal-mark_53866948.png" alt="Index Terminal mark" className="brand-mark" />
          <div><span className="eyebrow">THE INDEX / PRESCRIPT</span><strong>prescript<span className="brand-slash">/</span>01</strong></div>
        </div>
        <div className="top-status"><span className="status-dot" /> LINK STABLE <span className="status-divider">//</span> LOCAL SESSION</div>
        <button className="icon-button" onClick={() => setMenuOpen((open) => !open)} aria-label="Open controls"><Menu size={18} /></button>
        {menuOpen && <div className="command-menu">
          <button onClick={() => { setShowLexicon(true); setMenuOpen(false); }}><Database size={15} /> Open lexicon</button>
          <button onClick={() => { setNameDraft(name); setMenuOpen(false); document.getElementById("identity")?.focus(); }}><Settings2 size={15} /> Edit identity</button>
          <button onClick={toggleSound}>{soundEnabled ? <Volume2 size={15} /> : <VolumeX size={15} />} Audio link <span>{soundEnabled ? "ON" : "OFF"}</span></button>
          <label className="menu-upload"><Upload size={15} /> Load local SFX<input type="file" accept="audio/*" onChange={loadSound} /></label>
          <button onClick={() => toast("LOCAL MODE", { description: "BLE bridge reserved for the physical prototype." })}><Radio size={15} /> Pair device <span>soon</span></button>
        </div>}
      </header>

      <section className="workspace">
        <aside className="side-rail">
          <div className="rail-block"><span className="rail-label">SESSION</span><span className="rail-value">#{String(stats.received + 1).padStart(3, "0")}</span></div>
          <div className="rail-block"><span className="rail-label">RECEIVED</span><span className="rail-value cyan">{String(stats.received).padStart(2, "0")}</span></div>
          <div className="rail-block"><span className="rail-label">ARCHIVED</span><span className="rail-value">{String(stats.complete).padStart(2, "0")}</span></div>
          <div className="rail-block"><span className="rail-label">DECLINED</span><span className="rail-value muted">{String(stats.skipped).padStart(2, "0")}</span></div>
          <div className="rail-quote">“The message arrives. The choice remains yours.”</div>
        </aside>

        <section className="terminal-panel" aria-live="polite">
          <div className="terminal-head"><span>INCOMING / PRESCRIPT</span><span>{phase === "revealing" ? "DECODING" : phase === "ready" ? "READY" : phase === "complete" ? "ARCHIVED" : "STANDBY"}</span></div>
          <div className="terminal-screen">
            <div className="signal-lines" />
            <img src="/manus-storage/index-terminal-seal_ca0c8937.png" alt="Signal seal" className={`signal-seal ${phase === "revealing" ? "is-active" : ""}`} />
            <div className="receiver">TO {name.toUpperCase()} <span className="receiver-line">——</span></div>
            <div className={`command-copy ${phase === "revealing" ? "is-decoding" : ""}`}>
              <span className="bracket">[</span>
              <span>{decoded}</span>
              <span className="bracket">]</span><span className="cursor">_</span>
            </div>
            <div className="decode-meter"><span style={{ width: `${phase === "ready" || phase === "complete" ? 100 : Math.min(92, Math.max(3, (revealCount / Math.max(command.length, 1)) * 100))}%` }} /></div>
            <div className="terminal-note">{phase === "revealing" ? `REASSEMBLING GLYPHS / ${String(revealCount).padStart(3, "0")} OF ${String(command.length).padStart(3, "0")}` : phase === "ready" ? `INSTRUCTION LENGTH / ${String(lineCount).padStart(2, "0")} WORDS` : phase === "complete" ? "RECORD SEALED" : "NO ACTIVE INSTRUCTION"}</div>
          </div>
          <div className="terminal-actions">
            {phase === "idle" || phase === "complete" ? <button className="primary-action" onClick={receive}><Sparkles size={16} /> RECEIVE PRESCRIPT <span>↵</span></button> : <>
              <button className="primary-action" disabled={phase === "revealing"} onClick={() => finish("complete")}><Check size={16} /> PASS / COMPLETE</button>
              <button className="secondary-action" disabled={phase === "revealing"} onClick={() => finish("skip")}><SkipForward size={15} /> FAIL / DECLINE</button>
            </>}
            <button className="text-action" onClick={receive} disabled={phase === "revealing"}><RotateCcw size={14} /> NEW SIGNAL</button>
          </div>
        </section>

        <aside className="control-panel">
          <div className="panel-heading"><div><span className="eyebrow">OPERATOR PROFILE</span><h2>Identify operator</h2></div><CircleHelp size={17} /></div>
          <div className="identity-field"><label htmlFor="identity">DESIGNATION</label><input id="identity" value={nameDraft} onChange={(event) => setNameDraft(event.target.value)} onKeyDown={(event) => event.key === "Enter" && saveName()} /><button onClick={saveName}><Check size={15} /></button></div>
          <p className="panel-copy">ENTER A DESIGNATION. It will be written into each incoming Prescript and kept only in this browser.</p>
          <div className="panel-divider" />
          <div className="panel-heading"><div><span className="eyebrow">LEXICON</span><h2>Word storage</h2></div><Database size={17} /></div>
          <p className="panel-copy">Add words, places, objects, or phrases. The generator threads them into safe Prescripts.</p>
          <button className="lexicon-trigger" onClick={() => setShowLexicon(true)}><span><span className="lexicon-count">{String(words.length).padStart(2, "0")}</span> stored entries</span><ChevronDown size={15} /></button>
          <div className="safety-note"><span className="safety-mark">!</span><span><strong>SAFETY PROTOCOL</strong><br />Every starter Prescript is low-risk. You can always skip without consequence.{customSoundName && <><br /><span className="local-sound">SFX / {customSoundName}</span></>}</span></div>
        </aside>
      </section>

      <footer className="footer-bar"><span>LOCAL PRESCRIPT ENGINE / v0.1</span><span className="footer-center">NO OUTBOUND DATA · USER CONTROLLED</span><span>{new Date().toISOString().slice(0, 10)} <span className="footer-cyan">●</span></span></footer>

      {showLexicon && <div className="modal-backdrop" onClick={() => setShowLexicon(false)}><section className="lexicon-modal" onClick={(event) => event.stopPropagation()}>
        <div className="modal-head"><div><span className="eyebrow">LOCAL STORAGE / LEXICON</span><h2>Prescript vocabulary</h2></div><button className="icon-button" onClick={() => setShowLexicon(false)} aria-label="Close lexicon"><X size={18} /></button></div>
        <form className="add-word-form" onSubmit={addWord}><input value={newWord} onChange={(event) => setNewWord(event.target.value)} placeholder="Add a word or phrase…" aria-label="New word" /><button className="primary-action" type="submit"><Plus size={15} /> ADD ENTRY</button></form>
        <div className="word-list">{words.map((word) => <div className="word-row" key={word}><span>{word}</span><div><button title="Copy entry" onClick={() => { navigator.clipboard?.writeText(word); toast("ENTRY COPIED"); }}><Copy size={14} /></button><button title="Remove entry" onClick={() => removeWord(word)}><Trash2 size={14} /></button></div></div>)}</div>
        <div className="modal-foot"><span>{words.length} entries in local lexicon</span><button className="text-action" onClick={() => { setWords(starterWords); toast("LEXICON RESET"); }}>RESET TO STARTER SET</button></div>
      </section></div>}
    </main>
  );
}
