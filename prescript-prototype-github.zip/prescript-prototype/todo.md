# Single-file HTML checklist

## React prototype v0.2 follow-up

- [ ] ปรับ flow ให้มีหน้า boot/console และตัวเลือก PRESCRIPT กับ DECLINE
- [ ] เพิ่มสถานะ PASS/FAIL และเอฟเฟกต์ glitch ที่ปลอดภัย ไม่ลบไฟล์จริง
- [ ] เพิ่ม Web Audio API สำหรับ beep, static และ complete/fail cue
- [ ] เพิ่มปุ่มเปิด/ปิดเสียงและตัวเลือกอัปโหลดเสียงที่ผู้ใช้มีสิทธิ์ใช้งาน
- [ ] ปรับข้อความและตัวนับให้ใกล้ Prescript.exe โดยคงคำสั่งที่ปลอดภัย
- [ ] ทดสอบ build และสร้าง zip โปรเจกต์สำหรับ GitHub

# Single-file HTML checklist

- [x] สร้าง `prescript-single.html` ที่ฝัง CSS และ JavaScript ทั้งหมดไว้ในไฟล์เดียว
- [x] ฝังตราสัญลักษณ์เป็น inline SVG และไม่พึ่งพา asset ภายนอก
- [x] ทำระบบตั้งชื่อผู้ใช้และบันทึกด้วย localStorage
- [x] ทำระบบสุ่ม Prescript จาก starter vocabulary และคำที่ผู้ใช้เพิ่มเอง
- [x] ทำเอฟเฟกต์ scramble/reveal และสถานะ Complete/Skip
- [x] ทำหน้าต่างเพิ่ม/ลบ/คัดลอกคำศัพท์
- [x] ตรวจสอบ syntax และเปิดทดสอบบน browser
- [x] แนบไฟล์ HTML เดี่ยวให้ผู้ใช้ดาวน์โหลด
